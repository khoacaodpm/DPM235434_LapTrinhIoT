const int sensor = A1;
float tempc;
float tempf;
float vout;

void setup() {
  // put your setup code here, to run once:
  pinMode(sensor, INPUT);
  Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
  vout = analogRead(sensor);
  vout = (vout*500)/1023;
  tempc = vout;
  tempf = (vout*1.8)+32;
  Serial.print("in DegreeC=");
  Serial.print("\t");
  Serial.print(tempc);
  Serial.println();
  Serial.print("in Fahrenheit=");
  Serial.print("\t");
  Serial.print(tempf);
  Serial.println();
  delay(1000);
}
