#include <LiquidCrystal.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);
const int sensor = A1;
float tempc;
float tempf;
float vout;

void setup() {
  // put your setup code here, to run once:
  pinMode(sensor, INPUT);
  Serial.begin(9600);
  lcd.begin(16,2);
  delay(500);
}

void loop() {
  // put your main code here, to run repeatedly:
  vout = analogRead(sensor);
  vout = (vout*500)/1023.0;
  tempc = vout;
  tempf = (vout*1.8)+32;
  lcd.setCursor(0,0);
  lcd.print("DegreeC=");
  lcd.print(tempc);
  lcd.setCursor(0,1);
  lcd.print("Fahrenheit=");
  lcd.print(tempf);
  delay(1000);
}
