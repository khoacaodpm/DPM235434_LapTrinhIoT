int irPin = 8;
int ledPin = 13;
int objectDetected = LOW;

void setup() {
  // put your setup code here, to run once:
  pinMode(ledPin, OUTPUT);
  pinMode(irPin, INPUT);
  digitalWrite(irPin, HIGH);
}

void loop() {
  // put your main code here, to run repeatedly:
  objectDetected = digitalRead(irPin);
  if(LOW == objectDetected)
  {
    digitalWrite(ledPin, HIGH);
  }
  else
  {
    digitalWrite(ledPin, LOW);
  }
}
