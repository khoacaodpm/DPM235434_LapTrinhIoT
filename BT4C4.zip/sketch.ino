int buzzer = 8;
int LED = 7;
int flame_sensor = 4;
int flame_detected;

void setup() {
  Serial.begin(9600);
  pinMode(buzzer, OUTPUT);
  pinMode(LED, OUTPUT);
  pinMode(flame_sensor, INPUT);
}

void loop() {
  flame_detected = digitalRead(flame_sensor);

  if(flame_detected == 0) 
  {
    Serial.println("Phat hien ngon lua...!"); // Chuyển thành println để xuống dòng dễ đọc
    digitalWrite(buzzer, HIGH);
    digitalWrite(LED, HIGH);
    delay(200);
    digitalWrite(LED, LOW);
    delay(200);
  }
  else
  {
    Serial.println("Khong co lua phat hien");
    digitalWrite(buzzer, LOW);
    digitalWrite(LED, LOW);
  }
  delay(100);
}