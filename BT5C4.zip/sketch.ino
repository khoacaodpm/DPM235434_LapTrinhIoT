#include <IRremote.h>

const int receivePin = 8;
const int ledPin[] = {3,4,5,6,7,9,10,11,12,13};

boolean stateledPin3 = false;
boolean stateledPin4 = false;
boolean stateledPin5 = false;
boolean stateledPin6 = false;
boolean stateledPin7 = false;
boolean stateledPin9 = false;
boolean stateledPin10 = false;
boolean stateledPin11 = false;
boolean stateledPin12 = false;
boolean stateledPin13 = false;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  IrReceiver.begin(receivePin, ENABLE_LED_FEEDBACK); // Khởi tạo bộ thu IR theo chuẩn mới
  for(int i = 0; i < 10; i++)
  {
    pinMode(ledPin[i], OUTPUT);
  }
}

void translateIR() {
  // Đọc mã phím thông qua thuộc tính decodedRawData
  switch(IrReceiver.decodedIRData.decodedRawData)
  {
    case 0xFF6897: stateledPin3 = !stateledPin3;
      digitalWrite(ledPin[0], stateledPin3);
      break;
    case 0xFF30CF: stateledPin4 = !stateledPin4;
      digitalWrite(ledPin[1], stateledPin4);
      break;
    case 0xFF18E7: stateledPin5 = !stateledPin5;
      digitalWrite(ledPin[2], stateledPin5);
      break;
    case 0xFF7A85: stateledPin6 = !stateledPin6;
      digitalWrite(ledPin[3], stateledPin6);
      break;
    case 0xFF10EF: stateledPin7 = !stateledPin7;
      digitalWrite(ledPin[4], stateledPin7);
      break;
    case 0xFF38C7: stateledPin9 = !stateledPin9;
      digitalWrite(ledPin[5], stateledPin9);
      break;
    case 0xFF5AA5: stateledPin10 = !stateledPin10;
      digitalWrite(ledPin[6], stateledPin10);
      break;
    case 0xFF42BD: stateledPin11 = !stateledPin11;
      digitalWrite(ledPin[7], stateledPin11);
      break;
    case 0xFF4AB5: stateledPin12 = !stateledPin12;
      digitalWrite(ledPin[8], stateledPin12);
      break;
    case 0xFF52AD: stateledPin13 = !stateledPin13;
      digitalWrite(ledPin[9], stateledPin13);
      break;
  }
}

void loop() {
  // put your main code here, to run repeatedly:
  if(IrReceiver.decode()) // Kiểm tra tín hiệu IR theo cách gọi mới
  {
    translateIR();
    Serial.println(IrReceiver.decodedIRData.decodedRawData, HEX);
    delay(200);
    IrReceiver.resume(); // Sẵn sàng nhận tín hiệu kế tiếp
  }
}