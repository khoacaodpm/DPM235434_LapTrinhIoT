#include <DHT.h>

#define DHTPIN A0
#define DHTTYPE DHT22 

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  Serial.println();
  // Trả lại cột Status trên tiêu đề
  Serial.println("Status\tHumidity (%)\tTemperature (C)\t(F)");
  
  dht.begin();
}

void loop() {
  delay(2000);
  
  float humidity = dht.readHumidity();
  float tempC = dht.readTemperature();          
  float tempF = dht.readTemperature(true);      

  // Kiểm tra trạng thái và in ra cột Status
  if (isnan(humidity) || isnan(tempC) || isnan(tempF)) {
    Serial.print("Error\t");       // Trạng thái: Lỗi
    Serial.println("N/A\t\tN/A\t\tN/A");
  } else {
    Serial.print("OK\t");          // Trạng thái: Bình thường
    Serial.print(humidity, 1);
    Serial.print("\t\t");
    Serial.print(tempC, 1);
    Serial.print("\t\t");
    Serial.println(tempF, 1);
  }
}